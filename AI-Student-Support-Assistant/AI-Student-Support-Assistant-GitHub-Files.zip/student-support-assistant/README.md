# AI Student Support Assistant

A simple beginner-friendly web application for answering common college-related questions.

## Features
- Simple FAQ knowledge base
- Basic word-overlap retrieval (RAG concept)
- Office timing tool
- Short-term memory for the student's name
- Browser-based chat interface

## Technologies
Python, Flask, HTML, CSS, JavaScript, JSON

## Run locally

```bash
pip install -r requirements.txt
python app.py
```

Then open `http://127.0.0.1:5000` in a browser.

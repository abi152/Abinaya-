async function sendMessage() {
    const input = document.getElementById("message");
    const text = input.value.trim();

    if (!text) return;

    addMessage(text, "user");
    input.value = "";

    const response = await fetch("/chat", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({message: text})
    });

    const data = await response.json();
    addMessage(data.answer, "bot");
}

function addMessage(text, type) {
    const chat = document.getElementById("chat");
    const div = document.createElement("div");

    div.className = "msg " + type;
    div.textContent = text;

    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
}

document.getElementById("message").addEventListener("keydown", function(e) {
    if (e.key === "Enter") sendMessage();
});
